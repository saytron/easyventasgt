<?php
error_reporting(E_ALL ^ E_NOTICE);

require_once('../Model/class.conexion.php');
require_once('../Model/class.consultas.php');

header("Access-Control-Allow-Origin: *");

if (!isset($_SESSION)) {

		session_start();
		}
		$pass = $_SESSION['codigo'];
		$usuario = $_SESSION['usuario'];
		$rol = $_SESSION['rol'];


$DateAndTime = date('y-m-d', time());  
$Datos = json_decode(file_get_contents("php://input"));
// Si no hay datos, salir inmediatamente indicando un error 500
if (!$Datos) {
    // https://parzibyte.me/blog/2021/01/17/php-enviar-codigo-error-500/
    http_response_code(500);
    exit;
}
$nit	= $Datos->nit;
$name	= $Datos->nombre;
$direccion	= $Datos->direccion;
$idFactura	= $Datos->idfactura;


$consultas = new consultas();
$array = $consultas->cargarJsonFel($idFactura,$pass);
$totalPrecio = $consultas->cargarTotalVentasDetalle($idFactura,$pass);

$totalPrecioFactura = $totalPrecio[0]['total'];

$curl = curl_init();

$producto = json_encode($array);

$data = ' {
    "type": "FACT",
    "datetime_issue": "20'.$DateAndTime.'T00:00:00",
    "items": '.$producto.',
    "total": '.$totalPrecioFactura.',
    "total_tax": "0",
    "emails": [
        {
            "email": "example@exammple.com"
        }
    ],
    "emails_cc": [
        {
            "email": ""
        }
    ],
    "to_cf": 0,
    "to": {
        "tax_code_type": "NIT",
        "tax_code": "'.$nit.'",
        "tax_name": "'.$name.'",
        "address":  {
            "street": "'.$direccion.'",
            "city": "Mixco",
            "state": "Guatemala",
            "zip": "01001",
            "country": "GT"
        }
    },
    
    "exempt_phrase": null
   
}';


curl_setopt($curl, CURLOPT_URL, 'https://dev.app.felplex.com/api/entity/30/invoices');
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_ENCODING , '');
curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
curl_setopt($curl, CURLOPT_TIMEOUT, 0);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'Accept: application/json',
    'X-Authorization: qUsFnR0sJIUMkBRBKgxbm0QVp6vL8vRiFcQRtIy76JIfbIoOhVx0bJt652EsK412',
    'Content-Type: application/json'
  ));

$response = curl_exec($curl);

curl_close($curl);
$product = json_decode($response, true);
$id_prd = "";
$serie = "";
$certifierName = "";

$uuid = $product['uuid'];
$certifier = $product['certifier']['name'];
$taxCode = $product['certifier']['tax_code'];
$invoiceUrl = $product['invoice_url'];
$satSerie = $product['sat']['serie'];
$satNo = $product['sat']['no'];
$satAuthorization = $product['sat']['authorization'];
$certificationDate = $product['sat']['certification_date'];

//$consultas->actualizarVentasFel($uuid,$certifier,$taxCode,$invoiceUrl,$satSerie,$satNo,$satAuthorization,$certificationDate,$idFactura);

echo $response;
return true;