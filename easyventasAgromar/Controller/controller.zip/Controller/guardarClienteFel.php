<?php
error_reporting(E_ALL ^ E_NOTICE);
require_once('../Model/class.conexion.php');
require_once('../Model/class.consultas.php');

$nitCliente	= $_POST['nit'];
$nombreCliente = $_POST['nombre'];
$direccionCliente = $_POST['direccion'];
$consultas = new consultas();
$consultas->insertarCliente($nitCliente,$nombreCliente,'',$direccionCliente);
$id_cliente = $consultas->buscarClienteMax();
   $cliente;
   foreach($id_cliente as $filas){
	   $cliente = $filas['id_cliente'];
   }

$data =  $consultas->insertarTelefonoCliente('0', $cliente);
print_r($cliente);
