<?php
	error_reporting(E_ALL ^ E_NOTICE);
	require_once('../Model/class.conexion.php');
	require_once('../Model/class.consultas.php');

	if (!isset($_SESSION)) {

		session_start();
		}
		$pass = $_SESSION['codigo'];
		$usuario = $_SESSION['usuario'];
		$rol = $_SESSION['rol'];

	$id =  $_POST['id'];
	$nit = $_POST['nit'];
	$nombre = $_POST['nombre'];
	$apellido = $_POST['apellido'];
	$direccion = $_POST['direccion'];
	$validar_numeros = "1234567890.";


		$mensaje = null;
		
			if (strlen($id) >0 && strlen($nit) > 0 && strlen($nombre)  > 0 && strlen($direccion) > 0) {

				$consultas = new consultas();
				for ($i=0; $i<strlen($precio); $i++){
      		if (strpos($validar_numeros, substr($precio,$i,1))===false){
         echo "Caracteres no validos para el campo precio";
         return false;
      }
  }
		$mensaje = $consultas->actualizarCliente($id,$nit,$nombre,$apellido,$direccion);

		
			
		}else{
		

		$mensaje = "<h2>Debes llenar los campos</h2>";

		}


		

		echo $mensaje;
		return true;
		
?>