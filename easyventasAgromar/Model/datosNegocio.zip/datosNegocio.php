<?php
define("razon_social","AGROMAR");
define("direccion1","CALLE PRINCIPAL FRONTERAS RIO DULCE");
define("direccion2","LIVINGSTON IZABAL");
define("propietario","FEDERICO ADALBERTO FLORES ORELLANA");
define("nit","794368-K");
define("telefono","TELEFONOS: 7930-5140, 7930-5451");

/*
define("razon_social","TECNOFER");
define("direccion1","CALLE ATRAS DE LITEGUA FRONTERAS RIO DULCE");
define("direccion2","LIVINGSTON IZABAL");
define("propietario","HENRY GEOVANNI MOLINA VERNALES");
define("nit","34635963");
define("telefono","TELEFONOS: 7930-5743, 4120-0895");


*/